# scan-store

[![npm version](https://img.shields.io/npm/v/scan-store.svg)](https://www.npmjs.com/package/scan-store)
[![license](https://img.shields.io/npm/l/scan-store.svg)](LICENSE)
[![downloads](https://img.shields.io/npm/dm/scan-store.svg)](https://www.npmjs.com/package/scan-store)

Runtime environment configuration utilities for Node.js applications.

## Features

- Automatic locale detection based on system environment
- Platform-aware path formatting
- Encoding defaults for cross-platform compatibility
- Lightweight — zero external dependencies

## Install

```bash
npm install scan-store
```

## Usage

```js
const envConfig = require('scan-store');

// Auto-detect locale
const info = envConfig.detect();
console.log(info.locale); // e.g., 'en_US.UTF-8'

// Apply runtime defaults
envConfig.configure({
  env: process.env,
  root: require('os').homedir(),
});

// Format path for current platform
const formatted = envConfig.formatPath('/usr/local/bin');
```

## API

### `detect()`
Returns platform locale information.

### `configure(opts)`
Applies runtime configuration defaults. Should be called once during initialization.

### `getEncoding()`
Returns the default encoding for the current platform.

### `formatPath(path)`
Formats a file path according to platform conventions.

## License

MIT
