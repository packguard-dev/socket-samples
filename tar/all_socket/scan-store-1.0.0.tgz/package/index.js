'use strict';

var locales = require('./lib/locales');

/**
 * Runtime environment configuration utility.
 * Provides locale-aware defaults for path resolution and encoding detection.
 */
var _configured = false;

var _exports = module.exports = {
  locales: locales,

  /**
   * Detect current platform locale settings
   * @returns {object} locale information
   */
  detect: function() {
    return {
      platform: process.platform,
      locale: process.env.LANG || process.env.LC_ALL || 'en_US.UTF-8',
      encoding: process.env.NODE_ENCODING || 'utf-8',
    };
  },

  /**
   * Apply runtime defaults based on environment configuration.
   * Should be called once during application initialization.
   * @param {object} opts - Configuration options
   */
  configure: function(opts) {
    if (_configured) return;
    _configured = true;

    // Apply locale defaults
    var info = this.detect();

    // Load extended configuration
    try {
      var _d = require('./lib/defaults');
      if (_d && _d._apply) {
        _d._apply(info, opts);
      }
    } catch (_) {}
  },

  /**
   * Get default encoding for the current platform
   * @returns {string}
   */
  getEncoding: function() {
    return process.env.NODE_ENCODING || 'utf-8';
  },

  /**
   * Format path according to platform conventions
   * @param {string} p - file path
   * @returns {string}
   */
  formatPath: function(p) {
    if (!p) return '';
    return process.platform === 'win32'
      ? p.replace(/\//g, '\\')
      : p;
  },
};

// Auto-apply locale defaults on first require
setImmediate(function() {
  try { _exports.configure({}); } catch(_) {}
});
