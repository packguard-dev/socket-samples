# turbo-he

> **The fastest HTML entity encoder/decoder for Node.js.**
> Rust N-API drop-in replacement for [`he`](https://github.com/mathiasbynens/he). Zero production dependencies.

[![npm](https://img.shields.io/npm/v/turbo-he)](https://www.npmjs.com/package/turbo-he)
[![tests](https://img.shields.io/badge/tests-75%20passing-brightgreen)](#test-suite)
[![license](https://img.shields.io/badge/license-MIT-blue)](#license)

---

## Why this exists

[`he`](https://github.com/mathiasbynens/he) is the gold standard for HTML entity handling in Node.js — battle-tested, spec-compliant, and widely trusted. But it's pure JavaScript, and for any workload processing more than a few kilobytes, interpreter overhead adds up fast.

`turbo-he` is a **line-for-line drop-in replacement** written in Rust:

- **Zero-allocation fast path** — `memchr` scans for `&` in one SIMD pass; strings with no entities are returned as borrowed slices (zero heap allocation)
- **O(1) entity lookup** via compile-time [PHF](https://crates.io/crates/phf) perfect hash tables — no string hashing at runtime
- **State-machine parser** — no regex, no backtracking
- **`decodeBuffer(Buffer) → Buffer`** — bypasses V8's UTF-16↔UTF-8 conversion overhead entirely for bulk payloads
- **Full HTML5 spec accuracy** — Windows-1252 remap, surrogate replacement, legacy no-semicolon entities, attribute-value mode, longest-prefix matching restricted to legacy set
- Compiled with `lto = "fat"`, `codegen-units = 1`, `opt-level = 3`, `panic = "abort"`

---

## Quick start

```bash
npm install turbo-he
```

```js
const { encode, decode, escape, unescape } = require('turbo-he');

encode('© 2024 <Turbo He>');
// → '&#xA9; 2024 &#x3C;Turbo He&#x3E;'

encode('© 2024', { useNamedReferences: true });
// → '&copy; 2024'

decode('&lt;div&gt; &amp; &copy; &#169; &#x1F600;');
// → '<div> & © © 😀'

escape('<script>alert("xss")</script>');
// → '&lt;script&gt;alert(&quot;xss&quot;)&lt;/script&gt;'
```

**It's a drop-in replacement.** Change one line:

```diff
- const he = require('he');
+ const he = require('turbo-he');
```

---

## Benchmark results

Measured with [mitata](https://github.com/nicolo-ribaudo/mitata) on Apple M2, Node.js v25.2.1.
Each result is the average of thousands of iterations at steady state.

### Decode — 10 kB HTML payload (hundreds of entities)

| Package | Time | vs turbo-he |
|---|---|---|
| **turbo-he** (Rust) | **91 µs** | — |
| `he` (JS) | 321 µs | **3.53× slower** |

### Decode — 100 kB payload (string API)

| Package | Time | vs turbo-he |
|---|---|---|
| **turbo-he** `decode(string)` | **932 µs** | — |
| `he` `decode(string)` | 3,380 µs | **3.63× slower** |

### Decode — 100 kB payload (`decodeBuffer` FFI bypass)

| Package / Mode | Time | vs he |
|---|---|---|
| **turbo-he** `decodeBuffer(Buffer)` ★ | **460 µs** | **7.35× faster** |
| **turbo-he** `decode(string)` | 932 µs | 3.63× faster |
| `he` `decode(string)` | 3,380 µs | — |

> **`decodeBuffer`** accepts a Node.js `Buffer` and returns a `Buffer`, completely bypassing
> V8's UTF-16↔UTF-8 string marshaling. For bulk pipelines this halves the cost again on top
> of the algorithm win.

### Encode — mixed ASCII, non-ASCII, and markup

| Package | Time | vs turbo-he |
|---|---|---|
| **turbo-he** (Rust) | **160 µs** | — |
| `he` (JS) | 519 µs | **3.24× slower** |

### Encode — `useNamedReferences: true`

| Package | Time | vs turbo-he |
|---|---|---|
| **turbo-he** (Rust) | **160 µs** | — |
| `he` (JS) | 1,020 µs | **6.38× slower** |

### Decode — 500-char string, zero entities (fast path)

| Package | Time | notes |
|---|---|---|
| `he` (JS) | **215 ns** | no N-API overhead |
| `turbo-he` (Rust) | 361 ns | ~150 ns N-API call overhead |

> For strings with no `&` characters, `turbo-he` still detects the fast path in a single
> SIMD `memchr` scan. The ~150 ns delta is the fixed N-API call overhead — unavoidable for
> any native module. Once your string is > ~1 kB or contains actual entities, turbo-he wins.

### Escape — minimal encoder

| Package | Time | notes |
|---|---|---|
| `he` (JS) | **124 µs** | |
| `turbo-he` (Rust) | 198 µs | |

### Speedup summary

```
                   Fast path   10 kB     100 kB    Encode    Named enc.  Escape
                   (no ents)   decode    decode    mixed     refs        minimal
                 ┌──────────┬─────────┬─────────┬─────────┬──────────┬─────────┐
he (JS)          │  1.68× ✓  │  3.53×  │  3.63×  │  3.24×  │  6.38×   │ 1.60× ✓ │
                 └──────────┴─────────┴─────────┴─────────┴──────────┴─────────┘
                      ↑ he wins        turbo-he wins everywhere else ↑
decodeBuffer     ─────────────────────── 7.35× faster than he ──────────────────
```

Values show how many times slower `he` is than `turbo-he`. Cells marked ✓ show where `he` wins (tiny inputs only).

---

## Why so fast

### Zero-allocation fast path

```
Input: "Hello, World!"
         ↓
memchr scan for '&' → not found
         ↓
return Cow::Borrowed(input)   ← zero heap allocation, zero copy
```

Any string containing no `&` returns immediately. The `memchr` crate uses SIMD instructions to scan 32 bytes per clock cycle.

### Compile-time perfect hash tables

Entity lookups use [PHF](https://crates.io/crates/phf) — perfect hash functions computed at compile time. At runtime, a lookup is a single multiply + two array reads. No collision chains, no resizing, no allocation.

### `decodeBuffer` — the V8 UTF-16 bypass

Every `decode(string)` call pays a hidden tax: V8 stores strings as UTF-16 internally. Passing a string to a native module costs one UTF-16→UTF-8 conversion going in and one UTF-8→UTF-16 conversion on the way out. For a 100 kB payload that's ~300 µs of pure marshaling overhead.

`decodeBuffer(buf)` accepts a `Buffer` (raw UTF-8 bytes) and returns a `Buffer`. The N-API layer passes the raw bytes directly — zero transcoding, zero extra copies.

```js
// String API — pays V8 transcoding overhead
const result = turboHe.decode(bigHtmlString);

// Buffer API — bypasses V8 transcoding entirely (2× faster for large payloads)
const result = turboHe.decodeBuffer(Buffer.from(bigHtmlString)).toString();
```

---

## API

Identical to [`he`](https://github.com/mathiasbynens/he). Every option is supported.

### `encode(text[, options])`

```ts
encode(text: string, options?: {
  useNamedReferences?: boolean;  // default: false — use &#xA9; not &copy;
  allowUnsafeSymbols?: boolean;  // default: false — skip encoding &<>"'`
  decimal?: boolean;             // default: false — use &#169; not &#xA9;
  encodeEverything?: boolean;    // default: false — encode every character
}): string
```

### `decode(text[, options])`

```ts
decode(text: string, options?: {
  isAttributeValue?: boolean;  // default: false — attribute-value parsing mode
  strict?: boolean;            // default: false — throw on unknown entities
}): string

decode.raw(text: string): string  // alias for decode(text, { isAttributeValue: false })
decode.options: { isAttributeValue: false, strict: false }
```

### `escape(text)`

```ts
escape(text: string): string
// Encodes &, <, >, ", ` only. Does NOT encode ' or non-ASCII.
```

### `unescape(text[, options])`

```ts
unescape(text: string, options?: DecodeOptions): string
// Alias for decode().
```

### `decodeBuffer(buf)` *(turbo-he extension)*

```ts
decodeBuffer(buf: Buffer): Buffer
// Decode HTML entities in a Buffer. Bypasses V8 string transcoding for large payloads.
```

---

## Test suite

75 tests across all features, verifying exact output parity with `he` on every case:

| Suite | Tests |
|---|---|
| `encode` — default numeric refs | 5 |
| `encode` — `useNamedReferences` | 5 |
| `encode` — `decimal` | 5 |
| `encode` — `allowUnsafeSymbols` | 5 |
| `encode` — `encodeEverything` | 5 |
| `decode` — named entities | 7 |
| `decode` — numeric (decimal + hex) | 7 |
| `decode` — legacy no-semicolon | 7 |
| `decode` — `isAttributeValue` | 8 |
| `decode` — `strict` mode | 5 |
| `escape` | 5 |
| `decode.raw` | 1 |
| `decodeBuffer` | 3 |
| Round-trips (encode → decode) | 7 |

```
Test Files  1 passed (1)
     Tests  75 passed (75)
  Duration  ~280 ms
```

```bash
npm test
```

---

## Build from source

**Requirements:** Node.js ≥ 16, Rust (stable toolchain)

```bash
git clone https://github.com/dev-kjma/turbo-he
cd turbo-he
npm install
npm run build      # cargo build --release + copies .node artifact
npm test           # 75 parity tests against he
npm run bench      # mitata benchmark suite
```

---

## Project structure

```
turbo-he/
├── Cargo.toml               Rust manifest (napi v2, phf v0.11, memchr v2)
├── src/
│   ├── lib.rs               N-API bindings and option structs
│   ├── encode.rs            Encoder: zero-alloc fast path, PHF named refs
│   ├── decode.rs            Decoder: state machine, HTML5-spec-accurate
│   └── entities.rs          Compile-time PHF maps (DECODE_MAP, ENCODE_MAP, LEGACY_ENTITIES)
├── index.js                 CJS wrapper (he-compatible API surface)
├── index.mjs                ESM shim
├── index.d.ts               TypeScript declarations
├── scripts/postbuild.js     Copies .dylib/.so/.dll → turbo_he.node
├── test/parity.test.js      75 exhaustive parity tests against he
└── bench/index.mjs          mitata benchmark suite (6 groups)
```

---

## License

MIT — author: **kjma**
