// ESM re-export shim — delegates to the CJS index.js
import { createRequire } from 'module';
const require = createRequire(import.meta.url);
const mod = require('./index.js');
export const { encode, decode, escape, unescape, decodeBuffer } = mod;
export default mod;
