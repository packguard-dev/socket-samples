// turbo-he — drop-in type-compatible replacement for 'he'

export interface EncodeOptions {
  /** Use named references (e.g. `&copy;`) instead of numeric ones (`&#xA9;`). Default: `false` */
  useNamedReferences?: boolean;
  /** Skip encoding of `&`, `<`, `>`, `"`, `'`, `` ` `` — only encode non-ASCII. Default: `false` */
  allowUnsafeSymbols?: boolean;
  /** Use decimal numeric references (`&#169;`) instead of hex (`&#xA9;`). Default: `false` */
  decimal?: boolean;
  /** Encode every character, including safe ASCII. Default: `false` */
  encodeEverything?: boolean;
}

export interface DecodeOptions {
  /** Decode as an HTML attribute value (stricter legacy entity handling). Default: `false` */
  isAttributeValue?: boolean;
  /** Throw a `ParseError` on parse errors instead of silently replacing. Default: `false` */
  strict?: boolean;
}

/**
 * Encode HTML entities in `text`.
 * Encodes `&`, `<`, `>`, `"`, `'`, `` ` `` and all non-ASCII characters.
 * Drop-in replacement for `he.encode(text, options)`.
 */
export declare function encode(text: string, options?: EncodeOptions): string;

export declare namespace encode {
  /** Default option values. Can be mutated to change global defaults. */
  let options: Required<EncodeOptions>;
}

/**
 * Decode HTML entities in `text`.
 * Drop-in replacement for `he.decode(text, options)`.
 */
export declare function decode(text: string, options?: DecodeOptions): string;

export declare namespace decode {
  /** Default option values. Can be mutated to change global defaults. */
  let options: Required<DecodeOptions>;
  /** Decode in non-attribute-value mode (same as `decode(text, { isAttributeValue: false })`). */
  function raw(text: string): string;
}

/**
 * Minimal HTML escape: only `&`, `<`, `>`, `"`, `` ` ``.
 * Does NOT encode `'` or non-ASCII characters.
 * Drop-in replacement for `he.escape(text)`.
 */
export declare function escape(text: string): string;

/**
 * Alias for `decode`. Drop-in replacement for `he.unescape(text, options)`.
 */
export declare function unescape(text: string, options?: DecodeOptions): string;

/**
 * **Experimental — FFI bypass.**
 * Decode HTML entities in a Node.js `Buffer` and return a `Buffer`.
 * Avoids the V8 UTF-16 ↔ UTF-8 conversion cost that string arguments incur
 * on every N-API boundary crossing. Most beneficial for payloads ≥ 1 MB.
 */
export declare function decodeBuffer(buf: Buffer): Buffer;
