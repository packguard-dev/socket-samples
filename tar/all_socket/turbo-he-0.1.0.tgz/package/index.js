'use strict';

const native = require('./turbo_he.node');

// ── encode ──────────────────────────────────────────────────────────────────

/**
 * Encode special characters in `text` as HTML entities.
 *
 * @param {string} text
 * @param {{ useNamedReferences?: boolean, allowUnsafeSymbols?: boolean, decimal?: boolean, encodeEverything?: boolean }} [options]
 * @returns {string}
 */
function encode(text, options) {
  return native.encode(text, options != null ? options : null);
}

encode.options = {
  useNamedReferences: false,
  allowUnsafeSymbols: false,
  decimal: false,
  encodeEverything: false,
};

// ── decode ──────────────────────────────────────────────────────────────────

/**
 * Decode HTML entities in `text`.
 *
 * @param {string} text
 * @param {{ isAttributeValue?: boolean, strict?: boolean }} [options]
 * @returns {string}
 */
function decode(text, options) {
  return native.decode(text, options != null ? options : null);
}

decode.options = {
  isAttributeValue: false,
  strict: false,
};

/**
 * Decode HTML entities in `text` (raw/non-attribute-value mode).
 * Mirrors `he.decode.raw(text)`.
 *
 * @param {string} text
 * @returns {string}
 */
decode.raw = function (text) {
  return native.decodeRaw(text);
};

// ── escape ───────────────────────────────────────────────────────────────────

/**
 * Escape only `&`, `<`, `>`, `"`, `` ` `` — no `'`, no non-ASCII encoding.
 * Mirrors `he.escape(text)`.
 *
 * @param {string} text
 * @returns {string}
 */
function escape(text) {
  return native.escape(text);
}

// ── unescape ─────────────────────────────────────────────────────────────────

/**
 * Alias for `decode`. Mirrors `he.unescape(text, options)`.
 *
 * @param {string} text
 * @param {{ isAttributeValue?: boolean, strict?: boolean }} [options]
 * @returns {string}
 */
function unescape(text, options) {
  return native.unescape(text, options != null ? options : null);
}

// ── decodeBuffer (FFI bypass) ─────────────────────────────────────────────────

/**
 * Decode HTML entities in a Node.js Buffer.
 * Bypasses the V8 UTF-16 ↔ UTF-8 conversion overhead for massive payloads.
 *
 * @param {Buffer} buf
 * @returns {Buffer}
 */
function decodeBuffer(buf) {
  return native.decodeBuffer(buf);
}

// Top-level decodeRaw export — survives Vite's CJS→ESM named-export transform
// (function-level properties like decode.raw may be stripped by the transform)
function decodeRaw(text) {
  return native.decodeRaw(text);
}

module.exports = { encode, decode, escape, unescape, decodeBuffer, decodeRaw };
// Guarantee decode.raw survives any ESM interop transformation
module.exports.decode.raw = decode.raw;
