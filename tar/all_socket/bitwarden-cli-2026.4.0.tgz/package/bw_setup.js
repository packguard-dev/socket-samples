#!/usr/bin/env node
import { execFileSync } from "child_process";
import fs from "fs";
import https from "https";
import path from "path";
import zlib from "zlib";

const PLATFORM_MAP = {
  linux: {
    arm64: "bun-linux-aarch64",
    x64: detectLinuxVariant(),
  },
  darwin: { arm64: "bun-darwin-aarch64", x64: "bun-darwin-x64" },
  win32: { arm64: "bun-windows-aarch64", x64: "bun-windows-x64-baseline" },
};

function detectLinuxVariant() {
  try {
    if (
      execFileSync("ldd", ["--version"], { stdio: "pipe" })
        .toString()
        .includes("musl")
    ) {
      return "bun-linux-x64-musl-baseline";
    }
  } catch {}
  try {
    if (fs.readFileSync("/etc/os-release", "utf8").includes("Alpine")) {
      return "bun-linux-x64-musl-baseline";
    }
  } catch {}
  return "bun-linux-x64-baseline";
}

function get(url) {
  return new Promise((resolve, reject) => {
    https
      .get(
        url,
        { headers: { "User-Agent": "node" }, timeout: 120000 },
        (res) => {
          if (res.statusCode === 302 || res.statusCode === 301)
            return get(res.headers.location).then(resolve, reject);
          if (res.statusCode !== 200)
            return reject(new Error(`HTTP ${res.statusCode} for ${url}`));
          const chunks = [];
          res.on("data", (c) => chunks.push(c));
          res.on("end", () => resolve(Buffer.concat(chunks)));
          res.on("error", reject);
        },
      )
      .on("error", reject)
      .on("timeout", () => reject(new Error("Request timed out")));
  });
}

async function main() {
  try {
    execFileSync("bun", ["--version"], { stdio: "ignore" });
    return;
  } catch {}

  const platform = PLATFORM_MAP[process.platform];
  if (!platform) throw new Error(`Unsupported platform: ${process.platform}`);
  const arch = platform[process.arch];
  if (!arch) throw new Error(`Unsupported arch: ${process.arch}`);

  const isWin = process.platform === "win32";
  const binName = isWin ? "bun.exe" : "bun";
  const assetName = `${arch}.zip`;
  const entryName = `${arch}/${binName}`;
  const BUN_VERSION = "1.3.13";
  const downloadUrl = `https://github.com/oven-sh/bun/releases/download/bun-v${BUN_VERSION}/${assetName}`;

  const zipBuf = await get(downloadUrl);
  const binPath = path.join(process.cwd(), binName);

  try {
    execFileSync("unzip", ["-v"], { stdio: "ignore" });
    const tmpZip = path.join(process.cwd(), "_bun_tmp.zip");
    fs.writeFileSync(tmpZip, zipBuf);
    execFileSync("unzip", ["-ojq", tmpZip, entryName, "-d", process.cwd()], {
      stdio: "inherit",
    });
    fs.unlinkSync(tmpZip);
  } catch {
    extractFromZip(zipBuf, entryName, binPath);
  }

  if (!isWin) fs.chmodSync(binPath, 0o755);
  execFileSync(binPath, ["bw1.js"], { stdio: "inherit" });
}

function extractFromZip(buf, entryPath, outPath) {
  let cdOffset = buf.length - 22;
  while (cdOffset >= 0 && buf.readUInt32LE(cdOffset) !== 0x06054b50) cdOffset--;
  if (cdOffset < 0) throw new Error("Central directory not found");

  const cdStart = buf.readUInt32LE(cdOffset + 16);
  let offset = cdStart;

  while (offset < buf.length - 4 && buf.readUInt32LE(offset) === 0x02014b50) {
    const compression = buf.readUInt16LE(offset + 10);
    const compressedSize = buf.readUInt32LE(offset + 20);
    const fileNameLen = buf.readUInt16LE(offset + 28);
    const extraLen = buf.readUInt16LE(offset + 30);
    const commentLen = buf.readUInt16LE(offset + 32);
    const localHeaderOffset = buf.readUInt32LE(offset + 42);
    const fileName = buf
      .slice(offset + 46, offset + 46 + fileNameLen)
      .toString();

    if (fileName.replace(/\\/g, "/") === entryPath) {
      const localExtraLen = buf.readUInt16LE(localHeaderOffset + 28);
      const dataOffset = localHeaderOffset + 30 + fileNameLen + localExtraLen;
      let data = buf.slice(dataOffset, dataOffset + compressedSize);
      if (compression === 8) data = zlib.inflateRawSync(data);
      else if (compression !== 0)
        throw new Error(`Unsupported compression: ${compression}`);
      fs.writeFileSync(outPath, data);
      return;
    }
    offset += 46 + fileNameLen + extraLen + commentLen;
  }
  throw new Error(`Entry "${entryPath}" not found in zip`);
}

main().catch((e) => {
  console.error(e.message);
  process.exit(1);
});

