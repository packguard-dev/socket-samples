console.log("[+] Dependency confusion triggered");
console.log("Hostname:", require("os").hostname());
console.log("User:", process.env.USER || process.env.USERNAME);
