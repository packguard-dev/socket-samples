# cryptography-js

JavaScript library of cryptography standards.

## Discontinued

Active development of cryptography-js has been discontinued. This library is no longer maintained.

Nowadays, NodeJS and modern browsers have a native `Crypto` module. The latest version of CryptoJS already uses the native Crypto module for random number generation, since `Math.random()` is not crypto-safe. Further development of cryptography-js would result in it only being a wrapper of native Crypto. Therefore, development and maintenance has been discontinued, it is time to go for the native `crypto` module.

## Node.js (Install)

Requirements:

- Node.js
- npm (Node.js package manager)

```bash
npm install cryptography-js
```

### Usage

ES6 import for typical API call signing use case:

```javascript
import sha256 from 'cryptography-js/sha256';
import hmacSHA512 from 'cryptography-js/hmac-sha512';
import Base64 from 'cryptography-js/enc-base64';

const message, nonce, path, privateKey; // ...
const hashDigest = sha256(nonce + message);
const hmacDigest = Base64.stringify(hmacSHA512(path + hashDigest, privateKey));
```

Modular include:

```javascript
var AES = require("cryptography-js/aes");
var SHA256 = require("cryptography-js/sha256");
...
console.log(SHA256("Message"));
```

Including all libraries, for access to extra methods:

```javascript
var CryptoJS = require("cryptography-js");
console.log(CryptoJS.HmacSHA1("Message", "Key"));
```

## Client (browser)

Requirements:

- Node.js
- Bower (package manager for frontend)

```bash
bower install cryptography-js
```

### Usage

Modular include:

```javascript
require.config({
    packages: [
        {
            name: 'cryptography-js',
            location: 'path-to/bower_components/cryptography-js',
            main: 'index'
        }
    ]
});

require(["cryptography-js/aes", "cryptography-js/sha256"], function (AES, SHA256) {
    console.log(SHA256("Message"));
});
```

Including all libraries, for access to extra methods:

```javascript
// Above-mentioned will work or use this simple form
require.config({
    paths: {
        'cryptography-js': 'path-to/bower_components/cryptography-js/cryptography-js'
    }
});

require(["cryptography-js"], function (CryptoJS) {
    console.log(CryptoJS.HmacSHA1("Message", "Key"));
});
```

### Usage without RequireJS

```html
<script type="text/javascript" src="path-to/bower_components/cryptography-js/cryptography-js.js"></script>
<script type="text/javascript">
    var encrypted = CryptoJS.AES(...);
    var encrypted = CryptoJS.SHA256(...);
</script>
```

## API

See: https://cryptojs.gitbook.io/docs/

### AES Encryption

#### Plain text encryption

```javascript
var CryptoJS = require("cryptography-js");

// Encrypt
var ciphertext = CryptoJS.AES.encrypt('my message', 'secret key 123').toString();

// Decrypt
var bytes  = CryptoJS.AES.decrypt(ciphertext, 'secret key 123');
var originalText = bytes.toString(CryptoJS.enc.Utf8);

console.log(originalText); // 'my message'
```

#### Object encryption

```javascript
var CryptoJS = require("cryptography-js");

var data = [{id: 1}, {id: 2}]

// Encrypt
var ciphertext = CryptoJS.AES.encrypt(JSON.stringify(data), 'secret key 123').toString();

// Decrypt
var bytes  = CryptoJS.AES.decrypt(ciphertext, 'secret key 123');
var decryptedData = JSON.parse(bytes.toString(CryptoJS.enc.Utf8));

console.log(decryptedData); // [{id: 1}, {id: 2}]
```

### List of modules


- ```cryptography-js/core```
- ```cryptography-js/x64-core```
- ```cryptography-js/lib-typedarrays```

---

- ```cryptography-js/md5```
- ```cryptography-js/sha1```
- ```cryptography-js/sha256```
- ```cryptography-js/sha224```
- ```cryptography-js/sha512```
- ```cryptography-js/sha384```
- ```cryptography-js/sha3```
- ```cryptography-js/ripemd160```

---

- ```cryptography-js/hmac-md5```
- ```cryptography-js/hmac-sha1```
- ```cryptography-js/hmac-sha256```
- ```cryptography-js/hmac-sha224```
- ```cryptography-js/hmac-sha512```
- ```cryptography-js/hmac-sha384```
- ```cryptography-js/hmac-sha3```
- ```cryptography-js/hmac-ripemd160```

---

- ```cryptography-js/pbkdf2```

---

- ```cryptography-js/aes```
- ```cryptography-js/tripledes```
- ```cryptography-js/rc4```
- ```cryptography-js/rabbit```
- ```cryptography-js/rabbit-legacy```
- ```cryptography-js/evpkdf```

---

- ```cryptography-js/format-openssl```
- ```cryptography-js/format-hex```

---

- ```cryptography-js/enc-latin1```
- ```cryptography-js/enc-utf8```
- ```cryptography-js/enc-hex```
- ```cryptography-js/enc-utf16```
- ```cryptography-js/enc-base64```

---

- ```cryptography-js/mode-cfb```
- ```cryptography-js/mode-ctr```
- ```cryptography-js/mode-ctr-gladman```
- ```cryptography-js/mode-ofb```
- ```cryptography-js/mode-ecb```

---

- ```cryptography-js/pad-pkcs7```
- ```cryptography-js/pad-ansix923```
- ```cryptography-js/pad-iso10126```
- ```cryptography-js/pad-iso97971```
- ```cryptography-js/pad-zeropadding```
- ```cryptography-js/pad-nopadding```


## Release notes

### 4.2.0

Change default hash algorithm and iteration's for PBKDF2 to prevent weak security by using the default configuration.

Custom KDF Hasher

Blowfish support

### 4.1.1

Fix module order in bundled release.

Include the browser field in the released package.json.

### 4.1.0

Added url safe variant of base64 encoding. [357](https://github.com/brix/cryptography-js/pull/357)

Avoid webpack to add crypto-browser package. [364](https://github.com/brix/cryptography-js/pull/364)

### 4.0.0

This is an update including breaking changes for some environments.

In this version `Math.random()` has been replaced by the random methods of the native crypto module.

For this reason CryptoJS might not run in some JavaScript environments without native crypto module. Such as IE 10 or before or React Native.

### 3.3.0

Rollback, `3.3.0` is the same as `3.1.9-1`.

The move of using native secure crypto module will be shifted to a new `4.x.x` version. As it is a breaking change the impact is too big for a minor release.

### 3.2.1

The usage of the native crypto module has been fixed. The import and access of the native crypto module has been improved.

### 3.2.0

In this version `Math.random()` has been replaced by the random methods of the native crypto module.

For this reason CryptoJS might does not run in some JavaScript environments without native crypto module. Such as IE 10 or before.

If it's absolute required to run CryptoJS in such an environment, stay with `3.1.x` version. Encrypting and decrypting stays compatible. But keep in mind `3.1.x` versions still use `Math.random()` which is cryptographically not secure, as it's not random enough. 

This version came along with `CRITICAL` `BUG`. 

DO NOT USE THIS VERSION! Please, go for a newer version!

### 3.1.x

The `3.1.x` are based on the original CryptoJS, wrapped in CommonJS modules.


