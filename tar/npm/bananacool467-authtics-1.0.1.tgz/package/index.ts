/**
 * Authtics - Open Source Authentication Utility
 * Developed by bananakitssu (github.com/bananakitssu)
 * This software is provided "as-is" for the community.
 */

import { exec } from "child_process";

interface CurlHeader {
  k: string;
  v: string;
}

interface AuthticsUser {
  uid: string;
  name: string;
  profileImage: string;
}

const __runCurl__ = async (url: string, headers: CurlHeader[] = []) => {
  var outp;
  var oute;
  var curlReadableHeaders = headers
    .map((h: CurlHeader) => `-H "${h.k}: ${h.v}"`)
    .join(" ");
  return new Promise<[String?, String?]>((r) => {
    exec(
      `curl -X GET "${url}" ${curlReadableHeaders}`,
      (error, stdout, stderr) => {
        if (error) {
          oute = error.message;
          r([undefined, oute]);
          return;
        }
        outp = stdout;
        r([outp, undefined]);
      },
    );
  });
};

/**
 * Gets the user based on the accessToken.
 * The IP is required to lock all sessions for security reasons.
 */
export const getAccount = async (accessToken: string, clientId: string, clientSecret: string, userIp: string) => {
  var [output, error] = await __runCurl__("https://eb29e77b-9bd2-4e3b-9469-81d3af2a8fbe-00-1ag45w1mgbsv1.picard.replit.dev/api/authtics/me", [{k: "Authorization", v: accessToken}, {k: "x-client-id", v: clientId}, {k: "x-client-secret", v: clientSecret}, {k: "x-user-ip", v: userIp}, {k: "Content-Type", v: "application/json"}]);
  return (await JSON.parse(output as string)) || error;
}

/*(async () => {
  var [output, error] = await __runCurl__(
    "https://eb29e77b-9bd2-4e3b-9469-81d3af2a8fbe-00-1ag45w1mgbsv1.picard.replit.dev/api/authtics/me",
    [
      { k: "Authorization", v: "5" },
      { k: "client_id", v: "xxx" },
    ],
  );
  console.log(output, error);
})();*/
