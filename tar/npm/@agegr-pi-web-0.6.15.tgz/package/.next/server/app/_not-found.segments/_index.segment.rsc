1:"$Sreact.fragment"
2:I[57121,[],""]
3:I[74581,[],""]
:HL["/_next/static/css/e3601a99e60bc4e4.css","style"]
0:{"rsc":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/e3601a99e60bc4e4.css","precedence":"next"}]],["$","html",null,{"lang":"en","className":"__variable_66b8ca","suppressHydrationWarning":true,"children":[["$","head",null,{"children":["$","script",null,{"dangerouslySetInnerHTML":{"__html":"(function(){try{var t=localStorage.getItem(\"pi-theme\");if(t===\"dark\")document.documentElement.classList.add(\"dark\")}catch(e){}})();"}}]}],["$","body",null,{"style":{"height":"100dvh","display":"flex","flexDirection":"column"},"children":["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]}]]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"NzD1LVS5X1Dh4ZfgOVYhw"}
