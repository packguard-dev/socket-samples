1:"$Sreact.fragment"
2:"$Sreact.suspense"
3:I[23174,["7330","static/chunks/d3ac728e-7964f816a1ca64e5.js","194","static/chunks/194-d231a3ff99b573f9.js","8974","static/chunks/app/page-4ff17e43f501c9bf.js"],"AppShell"]
4:I[90484,[],"OutletBoundary"]
0:{"rsc":["$","$1","c",{"children":[["$","$2",null,{"children":["$","$L3",null,{}]}],null,["$","$L4",null,{"children":["$","$2",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"NzD1LVS5X1Dh4ZfgOVYhw"}
5:null
